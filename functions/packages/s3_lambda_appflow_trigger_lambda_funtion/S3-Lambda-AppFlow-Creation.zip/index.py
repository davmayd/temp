import os
import logging
import time
import boto3
import botocore
import cfnresponse
import psycopg2
from psycopg2 import connect, sql

def handler(event, context):
    try:
        logging.getLogger().setLevel(20)
        event_request_type = event['RequestType']
        logging.info("Event: %s", event)
        pg_data_types = {'sfid': 'character varying(18)', 'email': 'character varying(80)', 'url': 'character varying(255)', 'textarea': 'character varying(255)', 'reference': 'character varying(18)', 'picklist': 'character varying(40)', 'phone': 'character varying(40)', 'percent': 'double precision', 'int': 'integer', 'date': 'date', 'datetime': 'timestamp without time zone', 'complexvalue': 'character varying(255)', 'long': 'double precision', 'multipicklist': 'character varying(255)', 'anytype': 'character varying(255)', 'combobox': 'character varying(255)', 'encryptedstring': 'character varying(255)', 'number': 'character varying(255)', 'text': 'character varying(255)', 'string': 'character varying(255)', 'currency': 'double precision', 'address': 'character varying(3768)', 'double': 'double precision', 'boolean': 'boolean', 'junctionidlist': 'character varying(255)', 'datacategorygroupreference': 'character varying(255)'}
        object_list = os.environ['objects'].split(',')
        bucket = event['ResourceProperties']['the_bucket']
        response_data, connection = {}, None
        s3_client = boto3.client('s3')
        bucket_notification_configurations = s3_client.get_bucket_notification_configuration(Bucket=bucket)
        bucket_notification_configurations = bucket_notification_configurations['LambdaFunctionConfigurations'] if 'LambdaFunctionConfigurations' in bucket_notification_configurations else []
        s3_resource = boto3.resource('s3')
        bucket_notification = s3_resource.BucketNotification(bucket)
        lambda_client = boto3.client('lambda',region_name=os.environ['region'])
        appflow_client = boto3.client('appflow', region_name=os.environ['region'])

        if event_request_type in ('Create', 'Update'):
            connection = psycopg2.connect(user=os.environ['db_user'],
                password=os.environ['db_password'],
                host=os.environ['db_host'],
                port=os.environ['db_port'],
                database=os.environ['db_name'])
            connection.autocommit = True
            cursor = connection.cursor()
            for salesforce_object in object_list:
                logging.info("Creating S3 folder...")
                response = s3_client.put_object(Bucket=bucket,Key=(salesforce_object+'-Scheduled/'))
                logging.info("S3 Folder creation response: %s",response)

                logging.info('Creating Lambdas')
                response = lambda_client.create_function(
                    FunctionName=salesforce_object+'-Scheduled',
                    Role=os.environ['lambda_role'],
                    Code={'ImageUri': os.environ['image_uri']},
                    Timeout=300,
                    VpcConfig={'SubnetIds':os.environ['subnet_ids'].split(','),'SecurityGroupIds':[os.environ['securitygroup_ids']]},
                    PackageType='Image',
                    Environment={
                        'Variables': {
                            'db_host': os.environ['db_host'],
                            'db_name': os.environ['db_name'],
                            'db_port': '5432',
                            'db_password': os.environ['db_password'],
                            'db_user': os.environ['db_user'],
                            'table_name': salesforce_object.lower()
                        }
                    },
                )
                logging.info("Lambda Creation response: %s",response)

                lambda_arn = response['FunctionArn']
                logging.info('Adding Lambda Permission')
                response = lambda_client.add_permission(
                    FunctionName=salesforce_object+'-Scheduled',
                    StatementId=bucket+salesforce_object,
                    Action='lambda:InvokeFunction',
                    Principal='s3.amazonaws.com',
                    SourceArn='arn:aws:s3:::'+bucket,
                    SourceAccount=lambda_arn.split(':')[4]
                )
                logging.info("Lambda Permission response: %s",response)

                appflow_response = appflow_client.describe_connector_entity(connectorEntityName=salesforce_object, connectorType='Salesforce', connectorProfileName=os.environ['connection'])
                fields_list, task_fields, task_type = [], [], {}

                for record in appflow_response['connectorEntityFields']:
                    if record['supportedFieldTypeDetails']['v1']['fieldType'] == 'address':
                        continue
                    else:
                        fields_to_be_mapped = {}
                        fields_list.append(record['identifier'])
                        fields_to_be_mapped['destinationField'] = 'sfid' if record['identifier'] == 'Id' else record['identifier'].lower()
                        fields_to_be_mapped['taskType'] = 'Map'
                        fields_to_be_mapped['sourceFields'] = [record['identifier']]
                        fields_to_be_mapped['taskProperties'] = {'SOURCE_DATA_TYPE': record['supportedFieldTypeDetails']['v1']['fieldType'], 'DESTINATION_DATA_TYPE': record['supportedFieldTypeDetails']['v1']['fieldType']}
                        task_fields.append(fields_to_be_mapped)

                task_type['taskType'] = 'Filter'
                task_type['sourceFields'] = fields_list
                task_type['connectorOperator'] = {'Salesforce': 'PROJECTION'}
                task_fields.append(task_type)

                logging.info('Creating AppFlow flow')
                response = appflow_client.create_flow(
                    flowName=salesforce_object+'-Scheduled',
                    triggerConfig={
                        'triggerType': 'Scheduled',
                        'triggerProperties': {
                            'Scheduled': {
                               'scheduleExpression': 'rate(1minutes)',
                               'dataPullMode': 'Incremental'
                            }
                        }
                    },
                    sourceFlowConfig={
                        'connectorType': 'Salesforce',
                        'connectorProfileName': os.environ['connection'],
                        'sourceConnectorProperties': {
                            'Salesforce': {
                                'object': salesforce_object,
                                'enableDynamicFieldUpdate': False,
                                'includeDeletedRecords': True
                            },
                        }
                    },
                    destinationFlowConfigList=[
                        {
                            'connectorType': 'S3',
                            'destinationConnectorProperties': {
                                'S3': {
                                    'bucketName': bucket,
                                    's3OutputFormatConfig': {
                                        'fileType': 'JSON',
                                        'aggregationConfig': {
                                          'aggregationType': 'SingleFile'
                                        }
                                    }
                                }
                            }
                        },
                    ],
                    tasks=task_fields
                )
                logging.info("AppFlow flow creation response: %s",response)

                logging.info('Creating associated table')
                sf_field_types = [['sfid','character varying(18)']]

                for fields in appflow_response['connectorEntityFields']:
                    if fields['supportedFieldTypeDetails']['v1']['fieldType'] in pg_data_types:
                        sf_field_types.append([fields['identifier'].lower(),pg_data_types[fields['supportedFieldTypeDetails']['v1']['fieldType']]])
                    else:
                        continue

                columns_and_type = tuple((tuple(sub) for sub in sf_field_types))
                fields = []
                for col in columns_and_type:
                    fields.append( sql.SQL( "{} {}" ).format( sql.Identifier( col[0] ), sql.SQL( col[1] ) ) )

                query = sql.SQL( "CREATE TABLE {tbl_name} ( {fields} );" ).format(
                    tbl_name = sql.Identifier(salesforce_object.lower()),
                    fields = sql.SQL( ', ' ).join( fields )
                )
                cursor.execute(query)

                bucket_notification_configurations.append({'LambdaFunctionArn': lambda_arn,'Events': ['s3:ObjectCreated:*'],'Filter': { 'Key': { 'FilterRules': [{'Name': 'prefix', 'Value': salesforce_object+'-Scheduled/'},]}}},)

            time.sleep(120)
            logging.info('Adding Lambda Bucket Notifications')
            response = bucket_notification.put(NotificationConfiguration={'LambdaFunctionConfigurations': bucket_notification_configurations})
            logging.info("Lambda Bucket Notification response: %s",response)
        elif event_request_type == 'Delete':
            for salesforce_object in object_list:
                try:
                    logging.info('Deleting AppFlow Flow')
                    response = appflow_client.delete_flow(flowName=salesforce_object+'-Scheduled',forceDelete=True)
                    logging.info("AppFlow flow deletion response: %s",response)
                except botocore.exceptions.ClientError as e:
                    logging.info(e.response['Error']['Code'])
                    if e.response['Error']['Code'] == 'ResourceNotFoundException':
                        continue

            for salesforce_object in object_list:
                try:
                    logging.info('Deleting Lambdas')
                    response = lambda_client.delete_function(FunctionName=salesforce_object+'-Scheduled')
                    logging.info("Lambda deletion response: %s",response)
                except botocore.exceptions.ClientError as e:
                    logging.info(e.response['Error']['Code'])
                    if e.response['Error']['Code'] == 'ResourceNotFoundException':
                        continue

            for salesforce_object in object_list:
                response = s3_client.delete_object(Bucket=bucket,Key=(salesforce_object+'-Scheduled/'))
                logging.info("S3 folder deletion response: %s", response)

        cfnresponse.send(event,context,cfnresponse.SUCCESS,response_data)
    except Exception as e:
        logging.info(e)
        response_data['Data'] = str(e)
        cfnresponse.send(event,context,cfnresponse.FAILED,response_data)
    finally:
        if connection:
            cursor.close()
            connection.close()
            logging.info('PostgreSQL connection for creating table is closed')
